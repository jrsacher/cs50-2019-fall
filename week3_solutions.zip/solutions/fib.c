// Computes the nth Fibonacci number recursively
// 1, 1, 2, 3, 5, 8, 13 ...

#include <cs50.h>
#include <stdio.h>

unsigned long fib(int n)
{
    // Base case(s)
    if (n == 0)
    {
        return 1;
    }
    else if (n == 1)
    {
        return 1;
    }
    // Recursive case
    else
    {
        return fib(n - 1) + fib(n - 2);
    }
}

int main(void)
{
    int n = -1;
    while (n < 0)
    {
        n = get_int("Number: ");
    }
    unsigned long result = fib(n);
    printf("Fibonacci number %i is %lu\n", n, result);
}
