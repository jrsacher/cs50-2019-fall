// Gets int n from user, computes n! recursively
// EXAMPLE
//   4! = 4 * 3 * 2 * 1 = 24 (= 4 * 3!)

#include <cs50.h>
#include <stdio.h>

// Using an unsigned long to give us more space!
unsigned long factorial(int n)
{
    // Base case
    if (n == 0)
    {
        return 1;
    }
    // Recursive case
    return n * factorial(n - 1);
}

int main(void)
{
    int n = -1;
    while (n < 0)
    {
        n = get_int("Number: ");
    }
    unsigned long result = factorial(n);
    printf("%i! = %lu\n", n, result);
}
