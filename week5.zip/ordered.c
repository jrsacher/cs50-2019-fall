#include <cs50.h>
#include <stdio.h>

typedef struct node
{
    int number;
    struct node *next;
}
node;

int main(void)
{
    node *list = NULL;

    while (true)
    {
        // press ctrl-D to stop entering numbers!
        int x = get_int("Number: ");
        if (x == INT_MAX)
        {
            printf("\n");
            break;
        }

        // TODO: Allocate a new node.
		// TODO: Add new node to linked list lowest to highest.

    }

	// TODO: Print all nodes.
	// TODO: Free all nodes.

}
