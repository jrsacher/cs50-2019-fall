#include <cs50.h>
#include <ctype.h>
#include <stdio.h>

#define N 26

int hash(const char *word)
{
    return toupper(word[0] - 'A') % N;
}

int main(void)
{
    while (true)
    {
        char *s = get_string("word: ");
        printf("hashed: %i\n", hash(s));
    }
}
