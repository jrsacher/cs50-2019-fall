#include <cs50.h>
#include <ctype.h>
#include <stdio.h>

#define HASHTABLE_SIZE 32767  // (2 ^ 15) - 

unsigned int hash(const char *str)
{
    unsigned int hash = 5381, i = 0;
    while (str[i] != '\0')
    {
        // multiplication via bit shift: https://www.geeksforgeeks.org/left-shift-right-shift-operators-c-cpp/
        // lowercase via bitwise OR: https://c-for-dummies.com/blog/?p=1017
        hash = ((hash << 5) + hash) + (str[i] | 0x20);  // hash * 33 + tolower(c)
        i++;
    }
    return hash % HASHTABLE_SIZE;
}

int main(void)
{
    while (true)
    {
        char *s = get_string("word: ");
        printf("hashed: %i\n", hash(s));
    }
}
