#include <stdio.h>

#define MIN(x, y) (((x) < (y)) ? (x) : (y))
#define MAX(x, y) (((x) > (y)) ? (x) : (y))

int main(void)
{
    int a = 5;
    int b = 7;
    
    printf("min: %i\n", MIN(a, b));
    printf("max: %i\n", MAX(a, b));
}
