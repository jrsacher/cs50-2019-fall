#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int number;
    struct node *next;
}
node;

int main(void)
{
    node *list = NULL;

    while (true)
    {
        // press ctrl-D to stop entering numbers!
        int x = get_int("Number: ");
        if (x == INT_MAX)
        {
            printf("\n");
            break;
        }

        // Allocate a new node and store x
        node *n = malloc(sizeof(node));
        n->number = x;
        n->next = NULL;

		// Add new node to HEAD (beginning) of linked list.
        n->next = list;
        list = n;
    }

	// Print all nodes.
	for (node *tmp = list; tmp != NULL; tmp = tmp->next)
	{
        printf("%i\n", tmp->number);
	}
	// Free all nodes.
    node *ptr = list;
    while (ptr != NULL)
    {
        node *tmp = ptr;
        ptr = ptr-> next;
        free(tmp);
    }
}
