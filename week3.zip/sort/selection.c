/*
 * For i from 0 to n-1
 *   Find smallest item between i'th item and last item
 *   Swap smallest item with i'th item
 */

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 5000    // Number of values to sort

bool selection(int values[], int n)
{
    // Returns true if sorted, else false (for now)
    return false;
}


int main(void)
{
    int nums[N];
    srand(time(0));    // Set seed for random number generator based on time
    for (int i = 0; i < N; i++)
    {
        // Fill array with random numbers
        nums[i] = rand();
    }
    
    // Start timer
    time_t start = clock();
    
    // Call sorting function
    bool result = selection(nums, N);
    
    // Stop timer and calculate total time
    time_t stop = clock();
    double total = (double)(stop - start) / CLOCKS_PER_SEC;
    
    if (result)
    {
        printf("List sorted in %.5f seconds.\n", total);
        return 0;
    }
    
    else
    {
        printf("List not sorted.\n");
        return 1;
    }     
}
