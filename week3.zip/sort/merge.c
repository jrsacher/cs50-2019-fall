/* 
 * If only one item
 *   Return
 * Else
 *   Sort left half of items
 *   Sort right half of items
 *   Merge sorted halves
 */

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 5000    // Number of values to sort

void merge(int values[], int start_l, int stop_l, int start_r, int stop_r)
{
    return
}

void mergesort(int values[], int low, int high)
{
    // Sub-array is of length 1
    if (low >= high)
    {
        return;
    }

    int mid = (high + low) / 2;              // calculate midpoint(ish)
    mergesort(values, low, mid);             // sort left half
    mergesort(values, mid + 1, high);        // sort right half
    merge(values, low, mid, mid + 1, high);  // merge

    return;
}

int main(void)
{
    int nums[N];
    srand(time(0));    // Set seed for random number generator based on time
    for (int i = 0; i < N; i++)
    {
        // Fill array with random numbers
        nums[i] = rand();
    }

    for (int i = 0, j = sqrt(N); i < j; i++)
    {
        printf("%i ", nums[i]);
    }
    printf("...\n\n");

    // Start timer
    time_t start = clock();

    // Call sorting function
    // N - 1 is the last index of the array
    mergesort(nums, 0, N - 1);

    // Stop timer and calculate total time
    time_t stop = clock();
    double total = (double)(stop - start) / CLOCKS_PER_SEC;

    for (int i = 0, j = sqrt(N); i < j; i++)
    {
        printf("%i ", nums[i]);
    }
    printf("...\n\n");


    printf("List sorted in %.5f seconds.\n", total);
    return 0;
}
