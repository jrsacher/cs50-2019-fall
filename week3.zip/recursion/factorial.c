// Gets int n from user, computes n! recursively

#include <cs50.h>
#include <stdio.h>

int factorial(int n)
{
    // Base case
 
    // Recursive case
    
}

int main(void)
{
    int n = -1;
    while (n < 0)
    {
        n = get_int("Number: ");
    }
    int result = factorial(n);
    printf("%i! = %i", n, result);
}
