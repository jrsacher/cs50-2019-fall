// Computes the nth Fibonacci number recursively

#include <cs50.h>
#include <stdio.h>

int fib(int n)
{
    // Base case(s)
 
    // Recursive case
    
}

int main(void)
{
    int n = -1;
    while (n < 0)
    {
        n = get_int("Number: ");
    }
    int result = fib(n);
    printf("Fibonacci number %i is %i", n, result);
}
