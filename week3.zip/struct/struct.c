#include <cs50.h>
#include <stdio.h>

#define N 3

typedef struct
{

}
student;

int main(void)
{
    // Make an array of students
    student students[N];
    // Populate the array
    for (int i = 0; i < N; i++)
    {
        students[i].attr = get_string(": ");
    }
    
    // Print out some values
    printf("\n", );
    printf("\n", );
    printf("\n", );
}
