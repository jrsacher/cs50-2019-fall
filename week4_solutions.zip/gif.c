// Detect if a file is a GIF

#include <stdbool.h>
#include <stdio.h>

const char signature[6] = {'G', 'I', 'F', '8', '9', 'a'};

bool is_gif(FILE *f)
{
    // Read bytes into a buffer
    unsigned char buffer[6];
    int bytes = fread(buffer, 6, 1, f);
    // Check # of bytes read
    if (bytes != 1)
    {
        return false;
    }
    // Check each bite for gif signature
    for (int i = 0; i < 6; i++)
    {
        if (buffer[i] != signature[i])
        {
            return false;
        }
    }
    return true;
}


int main(int argc, char *argv[])
{
    // Check usage
    if (argc != 2)
    {
        printf("Usage: ./gif filename\n");
        return 1;
    }

    // Open file
    FILE *f = fopen(argv[1], "r");
    if (!f)
    {
        printf("Could not read file.\n");
        return 1;
    }

    // Check for GIF signature
    if (is_gif(f))
    {
        printf("GIF\n");
    }
    else
    {
        printf("NOT GIF\n");
    }

    // Close file, exit
    fclose(f);
    return 0;
}
