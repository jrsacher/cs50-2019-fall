/*
 * Repeat until no swaps
 *   For i from 0 to n-2
 *       If i'th and i+1'th elements out of order
 *           Swap them
 */

#include <cs50.h>
#include <locale.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 10000    // Number of values to sort (10,000)

void bubble(int values[], int n)
{
    for (int i = 0; i < n - 2; i++)
    {
        bool swaps = false;
        for (int j = 0; j < n - 2 - i; j++)
        {
            if (values[j] > values[j + 1])
            {
                swaps = true;
                int temp = values[j];
                values[j] = values[j + 1];
                values[j + 1] = temp;
            }
        }
    if (swaps == false)
        break;
    }
    return;
}


int main(void)
{
    int nums[N];
    srand(time(0));    // Set seed for random number generator based on time
    for (int i = 0; i < N; i++)
    {
        // Fill array with random numbers
        nums[i] = rand() % N;
    }

    for (int i = 0, j = sqrt(N); i < j; i++)
    {
        printf("%i ", nums[i]);
    }
    printf("...\n\n");

    // Start timer
    time_t start = clock();

    // Call sorting function
    bubble(nums, N);

    // Stop timer and calculate total time
    time_t stop = clock();
    double total = (double)(stop - start) / CLOCKS_PER_SEC;

    for (int i = 0, j = sqrt(N); i < j; i++)
    {
        printf("%i ", nums[i]);
    }
    printf("...\n\n");

    setlocale(LC_ALL, "en_US.utf8");     // for formatting (add comma to number)
    printf("%'d values sorted in %.5f seconds.\n", N, total);
    return 0;
}
