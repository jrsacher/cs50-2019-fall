#include <cs50.h>
#include <stdio.h>
#include <string.h>

// Takes in 2 strings, s1 and s2,
// returns a new string
char *concatenate(char *s1, char *s2)
{
    // TODO
    char *s3 = NULL;
    return s3;
}

int main(void)
{
    char *s1 = get_string("s1: ");
    char *s2 = get_string("s2: ");

    char *s3 = concatenate(s1, s2);
    printf("%s\n", s3);
    free(s3);
}
