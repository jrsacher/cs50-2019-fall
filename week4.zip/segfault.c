// Demonstrate what happens when you
// touch memory that isn't yours.
#include <cs50.h>
#include <stdio.h>

int main(void)
{
    char *s = get_string("s: ");
    printf("%c", *(s + 1000000));
}
