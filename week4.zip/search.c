#include <stdbool.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        fprintf(stderr, "Usage: ./search target_file word_to_find\n");
        return 1;
    }
    
    // Open file
    FILE *f = fopen(argv[1], "r");
    if (!f)
    {
        printf("Could not read file.\n");
        return 1;
    }
    
    // Store word in another variable for convenience
    char *word = argv[2];
    
    // Print "Found!" if word is found, else "Not found."
    
    return 0;
}
