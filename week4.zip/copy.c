// Users should be able to run ./copy file1 file2 to 
// copy the contents of text file file1 into file file2

#include <stdbool.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        fprintf(stderr, "Usage: ./copy infile outfile\n");
        return 1;
    }
    
    // Open file1 in read mode
   
    // Open file2 in write mode
  
    // Read one char at a time from file1 
    // and write to file 2 until EOF
  
    // Close files
    
    // Success!
    return 0;
}
