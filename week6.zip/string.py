def print_chars(s):
    """ Prints each letter in string s 1 per line """
    print()


def print_words(s):
    """ Prints each word in string s 1 per line """
    print()


def print_substrings(s, n):
    """ Prints all length n substrings of s 1 per line """
    print()


def print_reverse(s):
    """ Prints string from right to left """
    print()
    

def print_ascii(s):
    """ Prints ascii values of each character in s separated by a space """
    print()


s = "Hello, world! This is CS50 section."
print_chars(s)
print_words(s)
print_substrings(s, 5)
print_ascii(s)
print_reverse(s)
