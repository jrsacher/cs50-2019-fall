import csv

scores = []
# Open 2018 NFL regular season results
with open("NFL2018.csv") as f:
    # Create a csv reader or DictReader
    
    # Add all values to scores

# Check out the header and an example row
print()
print(scores[1].keys())
print()
print(scores[50])
print()

# What was the Patriots' 2018 record
win = 0
loss = 0


print(f"Patriots 2018 regular season record was {win} and {loss}")
print()

# Write out a csv file with just the Patriots results
with open("pats.csv", "w") as out:
    # Set header row values
    
    # Make a writer object
    
    # Write header
    
    # Write appropriate scores to the file
    
