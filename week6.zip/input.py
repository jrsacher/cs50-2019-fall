x = input("Input something here: ")

print(type(x))
